import os
from typing import List, Dict, Any, Tuple, Optional

from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma
from sentence_transformers import CrossEncoder
from retriever.config import RetrievalConfig
from retriever.metadata_filter import MetadataFilter
from retriever.hybrid_search import HybridSearcher
from retriever.diversity_selector import DiversitySelector
from utils.utils import setup_logger


class AdvancedRetriever:
    """
    Pipeline completo de recuperación avanzada.

    Orquesta todos los componentes:
    1. Búsqueda vectorial inicial
    2. Filtrado por metadatos
    3. Búsqueda híbrida (semántica + keywords)
    4. Reranking con cross-encoder
    5. Diversificación de fuentes
    6. Aplicación de thresholds de relevancia
    """

    def __init__(self, vector_db: Chroma, reranker: Optional[CrossEncoder] = None,
                 config: Optional[RetrievalConfig] = None):
        """
        Inicializa el retriever avanzado.

        Args:
            vector_db: Base de datos vectorial
            reranker: Modelo de reranking (opcional)
            config: Configuración del pipeline (opcional)
        """
        self.vector_db = vector_db
        self.reranker = reranker
        self.config = config or RetrievalConfig()

        # Componentes modulares
        self.metadata_filter = MetadataFilter(self.config)
        self.hybrid_searcher = HybridSearcher(self.config)
        self.diversity_selector = DiversitySelector(self.config)

        self.logger = setup_logger('AdvancedRetriever', level='INFO')

        self.logger.info("AdvancedRetriever inicializado")
        self.logger.info(f"   • Metadata filtering: {self.config.use_metadata_filter}")
        self.logger.info(f"   • Hybrid search: {self.config.use_hybrid_search}")
        self.logger.info(f"   • Reranking: {self.config.use_reranker and reranker is not None}")
        self.logger.info(f"   • Diversity: {self.config.use_diversity}")

    @staticmethod
    def _normalize_query_for_search(query: str) -> str:
        """
        Normaliza la query para búsqueda semántica.

        Remueve años específicos para evitar que la búsqueda vectorial
        se enfoque demasiado en fechas exactas, permitiendo recuperar
        documentos sobre el mismo tema con fechas diferentes (útil para
        detectar contradicciones).

        Args:
            query: Query original

        Returns:
            Query normalizada
        """
        import re
        # Remover años de 4 dígitos (pero mantener el contexto)
        # "fundado en 1903" → "fundado"
        normalized = re.sub(r'\b(19|20)\d{2}\b', '', query)
        # Limpiar espacios extras
        normalized = ' '.join(normalized.split())
        return normalized

    def retrieve(self, query: str, return_scores: bool = False) -> Tuple[List[Document], Optional[List[float]]]:
        """
        Recupera documentos relevantes con pipeline avanzado.

        Pipeline completo:
        1. Vector search (k_initial docs) - con query normalizada
        2. Metadata filtering & scoring
        3. Hybrid search (semantic + keywords)
        4. Reranking con cross-encoder - con query original
        5. Threshold filtering
        6. Diversity selection
        7. Top-K final

        Args:
            query: Consulta para búsqueda
            return_scores: Si retornar scores finales

        Returns:
            Tupla con:
            - Lista de documentos recuperados
            - Lista de scores (si return_scores=True)
        """
        self.logger.info(f"Iniciando recuperación avanzada para: '{query[:60]}...'")

        # === FASE 1: Búsqueda Vectorial Inicial (con query normalizada) ===
        # Normalizar query para búsqueda más amplia
        search_query = self._normalize_query_for_search(query)
        if search_query != query:
            self.logger.info(f"🔧 Query normalizada: '{query}' → '{search_query}'")

        self.logger.debug(f"[1/6] Búsqueda vectorial (k={self.config.k_initial})")
        initial_docs = self.vector_db.similarity_search(search_query, k=self.config.k_initial)

        # DEBUG: Mostrar primeros 3 chunks recuperados
        if initial_docs:
            self.logger.debug(f"📄 Primeros 3 chunks recuperados:")
            for i, doc in enumerate(initial_docs[:3], 1):
                preview = doc.page_content[:100].replace('\n', ' ')
                self.logger.debug(f"   {i}. {preview}...")

        if not initial_docs:
            self.logger.warning("No se encontraron documentos en la búsqueda vectorial")
            return ([], []) if return_scores else []

        self.logger.debug(f"      → {len(initial_docs)} documentos recuperados")

        # === FASE 2: Filtrado por Metadatos ===
        self.logger.debug("[2/6] Filtrado por metadatos")
        metadata_scored = self.metadata_filter.filter_and_score(search_query, initial_docs)

        # === FASE 3: Búsqueda Híbrida ===
        self.logger.debug("[3/6] Búsqueda híbrida (semántica + keywords)")
        # Extraer docs de metadata_scored
        docs_for_hybrid = [doc for doc, _ in metadata_scored]
        hybrid_scored = self.hybrid_searcher.hybrid_score(search_query, docs_for_hybrid)

        # Combinar scores de metadata e hybrid
        combined_scored = []
        for i, (doc, hybrid_score) in enumerate(hybrid_scored):
            metadata_score = metadata_scored[i][1]
            # Boost combinado
            boost = metadata_score * self.config.metadata_boost
            final_score = hybrid_score + boost
            combined_scored.append((doc, final_score))

        # === FASE 4: Reranking ===
        if self.config.use_reranker and self.reranker:
            self.logger.debug(f"[4/6] Reranking (top {self.config.rerank_top_k})")

            # Tomar top K para reranquear
            combined_scored.sort(key=lambda x: x[1], reverse=True)
            top_for_rerank = combined_scored[:self.config.rerank_top_k]

            # Aplicar reranker
            pairs = [[search_query, doc.page_content] for doc, _ in top_for_rerank]
            rerank_scores = self.reranker.predict(pairs)

            # Combinar scores
            reranked = []
            for (doc, prev_score), rerank_score in zip(top_for_rerank, rerank_scores):
                # Normalizar rerank score (suele estar en rango -10 a 10)
                normalized_rerank = (rerank_score + 10) / 20
                # Combinar: 70% rerank, 30% score previo
                combined = 0.7 * normalized_rerank + 0.3 * prev_score
                reranked.append((doc, combined, rerank_score))

            # Aplicar threshold de reranker
            reranked = [
                (doc, score, rs) for doc, score, rs in reranked
                if rs >= self.config.min_rerank_score
            ]

            self.logger.debug(
                f"      → {len(reranked)} documentos tras threshold "
                f"(min_score={self.config.min_rerank_score})"
            )

            # Mantener solo doc. y score combinado
            scored_docs = [(doc, score) for doc, score, _ in reranked]
        else:
            self.logger.debug("[4/6] Reranking deshabilitado, usando scores híbridos")
            scored_docs = combined_scored

        # === FASE 5: Threshold de Relevancia ===
        self.logger.debug(f"[5/6] Aplicando threshold mínimo ({self.config.min_relevance_score})")
        filtered_docs = [
            (doc, score) for doc, score in scored_docs
            if score >= self.config.min_relevance_score
        ]

        if not filtered_docs:
            self.logger.warning(
                f"Ningún documento supera el threshold de relevancia "
                f"({self.config.min_relevance_score})"
            )
            return ([], []) if return_scores else []

        self.logger.debug(f"      → {len(filtered_docs)} documentos relevantes")

        # === FASE 6: Diversificación ===
        self.logger.debug("[6/6] Diversificación de fuentes")
        diversified_docs = self.diversity_selector.diversify(filtered_docs)

        # === RESULTADO FINAL ===
        # Ordenar por score final y tomar top K
        diversified_docs.sort(key=lambda x: x[1], reverse=True)
        final_docs = diversified_docs[:self.config.final_top_k]

        self.logger.info(
            f"✅ Pipeline completado: {len(final_docs)} documentos finales "
            f"(desde {len(initial_docs)} iniciales)"
        )

        if return_scores:
            docs = [doc for doc, _ in final_docs]
            scores = [score for _, score in final_docs]
            return docs, scores

        return [doc for doc, _ in final_docs]

    def retrieve_with_context(self, query: str) -> Tuple[str, List[Dict[str, Any]]]:
        """
        Recupera documentos y construye contexto formateado.

        Compatible con la interfaz del FactChecker original.

        Args:
            query: Consulta para búsqueda

        Returns:
            Tupla con:
            - context: String formateado con evidencia y citaciones
            - metadata_list: Lista de metadatos de documentos
        """
        docs, scores = self.retrieve(query, return_scores=True)

        if not docs:
            return "", []

        # Construir contexto con citaciones
        context_parts = []
        metadata_list = []

        for i, (doc, score) in enumerate(zip(docs, scores), 1):
            filename = os.path.basename(
                doc.metadata.get("source", "Desconocido")
            )

            # Construir citación
            citation = self._build_citation(doc.metadata)

            # Header con score
            header = f"--- DOCUMENTO {i}: {filename}{citation} [Score: {score:.3f}] ---"
            clean_content = " ".join(doc.page_content.split())

            context_parts.append(f"{header}\n{clean_content}\n")

            metadata_list.append({
                'filename': filename,
                'citation': citation,
                'score': score,
                'metadata': doc.metadata
            })

        context = "\n".join(context_parts)

        return context, metadata_list

    @staticmethod
    def _build_citation(metadata: Dict[str, Any]) -> str:
        """
        Construye citación desde metadatos.

        Args:
            metadata: Metadatos del documento

        Returns:
            String de citación formateada
        """
        citation = ""

        if "page" in metadata:
            page_num = metadata['page'] + 1
            citation = f" (Pág. {page_num})"
        elif "chunk_id" in metadata:
            chunk_id = metadata['chunk_id']
            total_chunks = metadata.get('total_chunks_in_file', '?')
            citation = f" (Sec. {chunk_id}/{total_chunks})"

        return citation
