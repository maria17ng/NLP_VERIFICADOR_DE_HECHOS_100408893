import re
from typing import List, Tuple, Optional

from langchain_core.documents import Document
from retriever.config import RetrievalConfig
from utils.utils import setup_logger


class HybridSearcher:
    """
    Combina búsqueda semántica con keyword matching.

    Implementa BM25-like scoring sobre el contenido de documentos
    para complementar la búsqueda vectorial.
    """

    def __init__(self, config: RetrievalConfig):
        """
        Inicializa el buscador híbrido.

        Args:
            config: Configuración del pipeline
        """
        self.config = config
        self.logger = setup_logger('HybridSearcher', level='DEBUG')

    @staticmethod
    def extract_keywords(text: str) -> List[str]:
        """
        Extrae keywords significativas de un texto.

        Args:
            text: Texto a procesar

        Returns:
            Lista de keywords
        """
        # Normalizar y tokenizar
        text = text.lower()
        words = re.findall(r'\b\w+\b', text)

        # Filtrar stopwords comunes y palabras cortas
        stopwords = {
            'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas',
            'de', 'del', 'al', 'y', 'o', 'en', 'con', 'por', 'para',
            'que', 'es', 'su', 'se', 'como', 'más', 'fue', 'son',
            'the', 'a', 'an', 'and', 'or', 'in', 'on', 'at', 'to',
            'of', 'for', 'is', 'are', 'was', 'were', 'be', 'been'
        }

        keywords = [w for w in words if len(w) > 3 and w not in stopwords]

        return keywords

    def calculate_keyword_score(self, claim: str, document: Document) -> float:
        """
        Calcula score de keyword matching entre claim y documento.

        Args:
            claim: Afirmación
            document: Documento a evaluar

        Returns:
            Score de 0.0 a 1.0
        """
        claim_keywords = set(self.extract_keywords(claim))

        if not claim_keywords:
            return 0.0

        # Buscar en contenido y metadatos
        doc_text = document.page_content.lower()

        # Agregar texto de metadatos relevantes
        if 'keywords' in document.metadata:
            doc_text += ' ' + str(document.metadata['keywords']).lower()
        if 'title' in document.metadata:
            doc_text += ' ' + str(document.metadata['title']).lower()

        # Contar matches (con bonus por matches múltiples)
        matches = 0
        for keyword in claim_keywords:
            count = doc_text.count(keyword)
            if count > 0:
                matches += min(count, 3)  # Máximo 3 por keyword

        # Normalizar por número de keywords
        score = matches / (len(claim_keywords) * 2)  # Dividir por 2 para normalizar

        return min(score, 1.0)

    def hybrid_score(self, claim: str, documents: List[Document],
                     semantic_scores: Optional[List[float]] = None) -> List[Tuple[Document, float]]:
        """
        Combina scores semánticos con keyword matching.

        Args:
            claim: Afirmación
            documents: Lista de documentos
            semantic_scores: Scores semánticos previos (opcional)

        Returns:
            Lista de tuplas (documento, hybrid_score)
        """
        if not self.config.use_hybrid_search:
            default_score = 1.0 / len(documents) if documents else 0.0
            return [(doc, default_score) for doc in documents]

        hybrid_results = []

        for i, doc in enumerate(documents):
            keyword_score = self.calculate_keyword_score(claim, doc)

            # Combinar con score semántico si existe
            if semantic_scores and i < len(semantic_scores):
                semantic_score = semantic_scores[i]
            else:
                semantic_score = 1.0  # Asumir score neutral

            # Weighted combination
            hybrid = (
                    (1 - self.config.keyword_weight) * semantic_score +
                    self.config.keyword_weight * keyword_score
            )

            hybrid_results.append((doc, hybrid))

        self.logger.debug(
            f"Híbrido: {len([s for _, s in hybrid_results if s > 0.5])} docs con score > 0.5"
        )

        return hybrid_results
